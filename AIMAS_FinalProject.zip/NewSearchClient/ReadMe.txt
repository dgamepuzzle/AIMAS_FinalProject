To Run the client use the command:

Our main file is mainsearchclient.py

java -jar server.jar -c "py (path to mainsearchclient.py) -astar" -l "(path to level)" -g -s 100